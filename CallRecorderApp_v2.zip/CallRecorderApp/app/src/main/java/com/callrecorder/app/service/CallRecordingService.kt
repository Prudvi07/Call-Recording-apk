package com.callrecorder.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.callrecorder.app.R
import com.callrecorder.app.drive.DriveUploadWorker
import com.callrecorder.app.ui.MainActivity
import com.callrecorder.app.utils.AppDatabase
import com.callrecorder.app.utils.AppPreferences
import com.callrecorder.app.utils.Recording
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class CallRecordingService : LifecycleService() {

    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var recordingStartTime = 0L
    private var phoneNumber: String = "Unknown"
    private var callType: String = "INCOMING"

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var prefs: AppPreferences
    private lateinit var db: AppDatabase

    companion object {
        private const val TAG = "CallRecordingService"
        private const val NOTIFICATION_ID = 1001
        const val CHANNEL_ID = "call_recording_channel"
        const val ACTION_START_RECORDING = "START_RECORDING"
        const val ACTION_STOP_RECORDING  = "STOP_RECORDING"
        const val EXTRA_PHONE_NUMBER     = "phone_number"
        const val EXTRA_CALL_TYPE        = "call_type"

        fun startRecording(context: Context, phoneNumber: String, callType: String) {
            val intent = Intent(context, CallRecordingService::class.java).apply {
                action = ACTION_START_RECORDING
                putExtra(EXTRA_PHONE_NUMBER, phoneNumber)
                putExtra(EXTRA_CALL_TYPE, callType)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopRecording(context: Context) {
            val intent = Intent(context, CallRecordingService::class.java).apply {
                action = ACTION_STOP_RECORDING
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppPreferences.getInstance(this)
        db = AppDatabase.getInstance(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START_RECORDING -> {
                phoneNumber = intent.getStringExtra(EXTRA_PHONE_NUMBER) ?: "Unknown"
                callType    = intent.getStringExtra(EXTRA_CALL_TYPE) ?: "INCOMING"
                startForeground(NOTIFICATION_ID, buildNotification("Recording call..."))
                startRecording()
            }
            ACTION_STOP_RECORDING -> {
                stopRecordingAndSave()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        try {
            val dir = getExternalFilesDir("recordings")
                ?: filesDir.also { File(it, "recordings").mkdirs() }

            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val ext = if (prefs.recordingFormat == AppPreferences.FORMAT_MP3) "mp3" else "m4a"
            outputFile = File(dir, "call_${timestamp}_${sanitize(phoneNumber)}.$ext")

            mediaRecorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()).apply {

                setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(128000)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
                start()
            }

            recordingStartTime = System.currentTimeMillis()
            Log.d(TAG, "Recording started: ${outputFile!!.name}")

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording: ${e.message}")
            stopSelf()
        }
    }

    private fun stopRecordingAndSave() {
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null

            val duration = (System.currentTimeMillis() - recordingStartTime) / 1000
            val file = outputFile ?: run { stopSelf(); return }

            if (!file.exists() || file.length() == 0L) {
                Log.w(TAG, "Recording file is empty, discarding.")
                file.delete()
                stopSelf()
                return
            }

            serviceScope.launch {
                val recording = Recording(
                    filePath       = file.absolutePath,
                    fileName       = file.name,
                    phoneNumber    = phoneNumber,
                    callType       = callType,
                    durationSeconds = duration,
                    fileSizeBytes  = file.length(),
                    timestampMs    = System.currentTimeMillis()
                )
                val id = db.recordingDao().insertRecording(recording)
                Log.d(TAG, "Recording saved to DB, id=$id")

                if (prefs.isAutoUploadEnabled && prefs.isSignedIn()) {
                    DriveUploadWorker.enqueue(applicationContext, id)
                }

                withContext(Dispatchers.Main) { stopSelf() }
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording: ${e.message}")
            stopSelf()
        }
    }

    private fun buildNotification(text: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Call Recorder")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Call Recording",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shows when a call is being recorded" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun sanitize(number: String) = number.replace("[^0-9+]".toRegex(), "")

    override fun onDestroy() {
        serviceScope.cancel()
        mediaRecorder?.release()
        mediaRecorder = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? = super.onBind(intent)
}
