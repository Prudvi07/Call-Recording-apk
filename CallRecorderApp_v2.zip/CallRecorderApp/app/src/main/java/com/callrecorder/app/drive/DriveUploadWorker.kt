package com.callrecorder.app.drive

import android.content.Context
import android.util.Log
import androidx.work.*
import com.callrecorder.app.utils.AppDatabase
import com.callrecorder.app.utils.AppPreferences
import com.callrecorder.app.utils.UploadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class DriveUploadWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        private const val TAG = "DriveUploadWorker"
        private const val KEY_RECORDING_ID = "recording_id"

        fun enqueue(context: Context, recordingId: Long) {
            val prefs = AppPreferences.getInstance(context)
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(
                    if (prefs.uploadOnWifiOnly) NetworkType.UNMETERED
                    else NetworkType.CONNECTED
                )
                .build()

            val request = OneTimeWorkRequestBuilder<DriveUploadWorker>()
                .setInputData(workDataOf(KEY_RECORDING_ID to recordingId))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .addTag("upload_$recordingId")
                .build()

            WorkManager.getInstance(context).enqueue(request)
            Log.d(TAG, "Upload enqueued for recording id=$recordingId")
        }

        /** Re-enqueue all failed or pending uploads (e.g., on app start) */
        fun retryPending(context: Context) {
            val db    = AppDatabase.getInstance(context)
            val prefs = AppPreferences.getInstance(context)
            if (!prefs.isSignedIn()) return

            kotlinx.coroutines.GlobalScope.launch(Dispatchers.IO) {
                val pending = db.recordingDao().getRecordingsByStatus(UploadStatus.PENDING) +
                              db.recordingDao().getRecordingsByStatus(UploadStatus.FAILED)
                pending.forEach { enqueue(context, it.id) }
            }
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val recordingId = inputData.getLong(KEY_RECORDING_ID, -1)
        if (recordingId == -1L) return@withContext Result.failure()

        val db = AppDatabase.getInstance(applicationContext)
        val prefs = AppPreferences.getInstance(applicationContext)
        val recording = db.recordingDao().getRecordingById(recordingId) ?: return@withContext Result.failure()

        val localFile = File(recording.filePath)
        if (!localFile.exists()) {
            Log.w(TAG, "Local file missing: ${recording.filePath}")
            return@withContext Result.failure()
        }

        // Mark as uploading
        db.recordingDao().updateRecording(recording.copy(uploadStatus = UploadStatus.UPLOADING))

        return@withContext try {
            val driveHelper = DriveHelper(applicationContext)
            val result = driveHelper.uploadFile(localFile)

            db.recordingDao().updateRecording(
                recording.copy(
                    uploadStatus = UploadStatus.UPLOADED,
                    driveFileId  = result.fileId,
                    driveLink    = result.webViewLink
                )
            )
            Log.d(TAG, "Upload success: ${recording.fileName}")

            if (prefs.deleteAfterUpload) {
                localFile.delete()
                Log.d(TAG, "Local file deleted after upload.")
            }

            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Upload failed: ${e.message}")
            db.recordingDao().updateRecording(recording.copy(uploadStatus = UploadStatus.FAILED))
            Result.retry()
        }
    }
}
