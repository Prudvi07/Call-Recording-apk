package com.callrecorder.app.drive

import android.content.Context
import android.util.Log
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.callrecorder.app.utils.AppPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class DriveUploadResult(
    val fileId: String,
    val webViewLink: String
)

class DriveHelper(context: Context) {

    private val prefs = AppPreferences.getInstance(context)
    private val appContext = context.applicationContext

    private fun buildDriveService(): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            appContext, listOf(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccountName = prefs.googleAccountEmail
        }
        return Drive.Builder(
            NetHttpTransport(),
            GsonFactory.getDefaultInstance(),
            credential
        ).setApplicationName("CallRecorder").build()
    }

    /**
     * Upload a local audio file to Google Drive.
     * Creates the target folder if it doesn't exist yet.
     */
    suspend fun uploadFile(localFile: File): DriveUploadResult = withContext(Dispatchers.IO) {
        val drive = buildDriveService()
        val folderId = getOrCreateFolder(drive)

        val mimeType = when (localFile.extension.lowercase()) {
            "mp3"  -> "audio/mpeg"
            "m4a"  -> "audio/mp4"
            "3gp"  -> "audio/3gpp"
            else   -> "audio/*"
        }

        val meta = DriveFile().apply {
            name    = localFile.name
            parents = listOf(folderId)
        }
        val content = FileContent(mimeType, localFile)

        val uploaded = drive.files().create(meta, content)
            .setFields("id,webViewLink")
            .execute()

        Log.d(TAG, "Uploaded ${localFile.name} → id=${uploaded.id}")
        DriveUploadResult(uploaded.id, uploaded.webViewLink ?: "")
    }

    /**
     * Delete a file from Drive by its file ID.
     */
    suspend fun deleteFile(driveFileId: String) = withContext(Dispatchers.IO) {
        buildDriveService().files().delete(driveFileId).execute()
    }

    // ── Private helpers ──────────────────────────────────────────────────────

    private fun getOrCreateFolder(drive: Drive): String {
        val cachedId = prefs.driveFolderId
        if (cachedId != null) return cachedId

        val folderName = prefs.driveFolderName
        // Check if folder already exists
        val query = "mimeType='application/vnd.google-apps.folder' and name='$folderName' and trashed=false"
        val result = drive.files().list().setQ(query).setFields("files(id)").execute()
        val existing = result.files.firstOrNull()
        if (existing != null) {
            prefs.driveFolderId = existing.id
            return existing.id
        }

        // Create new folder
        val folderMeta = DriveFile().apply {
            name     = folderName
            mimeType = "application/vnd.google-apps.folder"
        }
        val folder = drive.files().create(folderMeta).setFields("id").execute()
        prefs.driveFolderId = folder.id
        Log.d(TAG, "Created Drive folder '$folderName' id=${folder.id}")
        return folder.id
    }

    companion object {
        private const val TAG = "DriveHelper"
    }
}
