package com.callrecorder.app.ui

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.callrecorder.app.databinding.ActivityRecordingDetailBinding
import com.callrecorder.app.utils.AppDatabase
import com.callrecorder.app.utils.UploadStatus
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RecordingDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRecordingDetailBinding
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var updateSeekRunnable: Runnable? = null

    companion object {
        private const val EXTRA_ID = "recording_id"
        private val DATE_FMT = SimpleDateFormat("MMM dd, yyyy  HH:mm:ss", Locale.getDefault())

        fun newIntent(context: Context, id: Long) =
            Intent(context, RecordingDetailActivity::class.java).putExtra(EXTRA_ID, id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val id = intent.getLongExtra(EXTRA_ID, -1)
        if (id == -1L) { finish(); return }

        lifecycleScope.launch {
            val rec = AppDatabase.getInstance(this@RecordingDetailActivity)
                .recordingDao().getRecordingById(id) ?: run { finish(); return@launch }

            binding.tvPhoneNumber.text = rec.phoneNumber.ifBlank { "Unknown" }
            binding.tvCallType.text    = rec.callType
            binding.tvDate.text        = DATE_FMT.format(Date(rec.timestampMs))
            binding.tvDuration.text    = formatDuration(rec.durationSeconds)
            binding.tvFileSize.text    = formatSize(rec.fileSizeBytes)
            binding.tvFileName.text    = rec.fileName
            binding.tvStatus.text      = rec.uploadStatus
            binding.tvDriveLink.text   = rec.driveLink ?: "—"

            rec.driveLink?.let { link ->
                binding.btnOpenDrive.setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
                }
            }

            val file = File(rec.filePath)
            if (file.exists()) setupPlayer(file)
            else binding.tvPlayerNote.text = "Local file not available (deleted after upload)"
        }
    }

    private fun setupPlayer(file: File) {
        val player = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
        }.also { mediaPlayer = it }

        binding.seekBar.max = player.duration
        binding.tvPlayerDuration.text = formatMs(player.duration)

        binding.btnPlayPause.setOnClickListener {
            if (player.isPlaying) {
                player.pause()
                binding.btnPlayPause.text = "▶ Play"
                stopSeekUpdate()
            } else {
                player.start()
                binding.btnPlayPause.text = "⏸ Pause"
                startSeekUpdate(player)
            }
        }

        binding.seekBar.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) player.seekTo(progress)
                binding.tvPlayerPosition.text = formatMs(progress)
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar) {}
        })

        player.setOnCompletionListener {
            binding.btnPlayPause.text = "▶ Play"
            stopSeekUpdate()
        }
    }

    private fun startSeekUpdate(player: MediaPlayer) {
        updateSeekRunnable = object : Runnable {
            override fun run() {
                if (player.isPlaying) {
                    binding.seekBar.progress = player.currentPosition
                    handler.postDelayed(this, 500)
                }
            }
        }.also { handler.post(it) }
    }

    private fun stopSeekUpdate() {
        updateSeekRunnable?.let { handler.removeCallbacks(it) }
    }

    private fun formatDuration(s: Long) = "%d:%02d".format(s / 60, s % 60)
    private fun formatMs(ms: Int) = "%d:%02d".format(ms / 60000, (ms % 60000) / 1000)
    private fun formatSize(bytes: Long) = when {
        bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
        else               -> "%.1f KB".format(bytes / 1_000.0)
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }

    override fun onDestroy() {
        stopSeekUpdate()
        mediaPlayer?.release()
        mediaPlayer = null
        super.onDestroy()
    }
}
