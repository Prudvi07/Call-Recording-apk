package com.callrecorder.app.utils

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ─── Entity ──────────────────────────────────────────────────────────────────

@Entity(tableName = "recordings")
data class Recording(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val filePath: String,
    val fileName: String,
    val phoneNumber: String,
    val callType: String,          // "INCOMING" | "OUTGOING"
    val durationSeconds: Long,
    val fileSizeBytes: Long,
    val timestampMs: Long,
    val uploadStatus: String = UploadStatus.PENDING,  // PENDING | UPLOADING | UPLOADED | FAILED
    val driveFileId: String? = null,
    val driveLink: String? = null
)

object UploadStatus {
    const val PENDING   = "PENDING"
    const val UPLOADING = "UPLOADING"
    const val UPLOADED  = "UPLOADED"
    const val FAILED    = "FAILED"
}

// ─── DAO ─────────────────────────────────────────────────────────────────────

@Dao
interface RecordingDao {

    @Query("SELECT * FROM recordings ORDER BY timestampMs DESC")
    fun getAllRecordings(): Flow<List<Recording>>

    @Query("SELECT * FROM recordings WHERE uploadStatus = :status")
    suspend fun getRecordingsByStatus(status: String): List<Recording>

    @Insert
    suspend fun insertRecording(recording: Recording): Long

    @Update
    suspend fun updateRecording(recording: Recording)

    @Delete
    suspend fun deleteRecording(recording: Recording)

    @Query("SELECT * FROM recordings WHERE id = :id")
    suspend fun getRecordingById(id: Long): Recording?
}

// ─── Database ─────────────────────────────────────────────────────────────────

@Database(entities = [Recording::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun recordingDao(): RecordingDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "call_recorder_db"
                ).build().also { INSTANCE = it }
            }
    }
}
