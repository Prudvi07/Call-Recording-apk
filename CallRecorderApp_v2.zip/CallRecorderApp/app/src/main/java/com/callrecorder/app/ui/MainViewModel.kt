package com.callrecorder.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.callrecorder.app.drive.DriveUploadWorker
import com.callrecorder.app.utils.AppDatabase
import com.callrecorder.app.utils.AppPreferences
import com.callrecorder.app.utils.Recording
import com.callrecorder.app.utils.UploadStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val db    = AppDatabase.getInstance(app)
    private val prefs = AppPreferences.getInstance(app)

    val recordings = db.recordingDao().getAllRecordings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun deleteRecording(recording: Recording) = viewModelScope.launch {
        File(recording.filePath).delete()
        db.recordingDao().deleteRecording(recording)
    }

    fun retryUpload(recording: Recording) = viewModelScope.launch {
        db.recordingDao().updateRecording(recording.copy(uploadStatus = UploadStatus.PENDING))
        DriveUploadWorker.enqueue(getApplication(), recording.id)
    }

    fun uploadAll() = viewModelScope.launch {
        val pending = db.recordingDao().getRecordingsByStatus(UploadStatus.PENDING) +
                      db.recordingDao().getRecordingsByStatus(UploadStatus.FAILED)
        pending.forEach { DriveUploadWorker.enqueue(getApplication(), it.id) }
    }

    fun toggleRecording(enabled: Boolean) {
        prefs.isRecordingEnabled = enabled
    }

    fun toggleAutoUpload(enabled: Boolean) {
        prefs.isAutoUploadEnabled = enabled
    }

    val isRecordingEnabled get() = prefs.isRecordingEnabled
    val isAutoUploadEnabled get() = prefs.isAutoUploadEnabled
    val isSignedIn get() = prefs.isSignedIn()
    val accountEmail get() = prefs.googleAccountEmail
}
