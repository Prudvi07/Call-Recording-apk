package com.callrecorder.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.callrecorder.app.databinding.ActivitySettingsBinding
import com.callrecorder.app.utils.AppPreferences

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: AppPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            title = "Settings"
        }

        prefs = AppPreferences.getInstance(this)
        loadSettings()
        binding.btnSave.setOnClickListener { saveSettings() }
    }

    private fun loadSettings() {
        binding.switchWifiOnly.isChecked = prefs.uploadOnWifiOnly
        binding.switchDeleteAfterUpload.isChecked = prefs.deleteAfterUpload
        binding.etFolderName.setText(prefs.driveFolderName)
        binding.radioGroupFormat.check(
            if (prefs.recordingFormat == AppPreferences.FORMAT_MP3)
                com.callrecorder.app.R.id.radioMp3
            else
                com.callrecorder.app.R.id.radioM4a
        )
    }

    private fun saveSettings() {
        prefs.uploadOnWifiOnly     = binding.switchWifiOnly.isChecked
        prefs.deleteAfterUpload    = binding.switchDeleteAfterUpload.isChecked
        prefs.driveFolderName      = binding.etFolderName.text.toString().trim()
            .ifBlank { "CallRecordings" }
        prefs.driveFolderId        = null // reset so new folder name takes effect
        prefs.recordingFormat      = if (binding.radioMp3.isChecked)
            AppPreferences.FORMAT_MP3 else AppPreferences.FORMAT_M4A

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
