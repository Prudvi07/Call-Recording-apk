package com.callrecorder.app.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("call_recorder_prefs", Context.MODE_PRIVATE)

    var isRecordingEnabled: Boolean
        get() = prefs.getBoolean(KEY_RECORDING_ENABLED, true)
        set(value) = prefs.edit { putBoolean(KEY_RECORDING_ENABLED, value) }

    var isAutoUploadEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_UPLOAD, true)
        set(value) = prefs.edit { putBoolean(KEY_AUTO_UPLOAD, value) }

    var uploadOnWifiOnly: Boolean
        get() = prefs.getBoolean(KEY_WIFI_ONLY, true)
        set(value) = prefs.edit { putBoolean(KEY_WIFI_ONLY, value) }

    var googleAccountEmail: String?
        get() = prefs.getString(KEY_GOOGLE_ACCOUNT, null)
        set(value) = prefs.edit { putString(KEY_GOOGLE_ACCOUNT, value) }

    var driveFolderId: String?
        get() = prefs.getString(KEY_DRIVE_FOLDER_ID, null)
        set(value) = prefs.edit { putString(KEY_DRIVE_FOLDER_ID, value) }

    var driveFolderName: String
        get() = prefs.getString(KEY_DRIVE_FOLDER_NAME, "CallRecordings") ?: "CallRecordings"
        set(value) = prefs.edit { putString(KEY_DRIVE_FOLDER_NAME, value) }

    var recordingFormat: String
        get() = prefs.getString(KEY_RECORDING_FORMAT, FORMAT_M4A) ?: FORMAT_M4A
        set(value) = prefs.edit { putString(KEY_RECORDING_FORMAT, value) }

    var deleteAfterUpload: Boolean
        get() = prefs.getBoolean(KEY_DELETE_AFTER_UPLOAD, false)
        set(value) = prefs.edit { putBoolean(KEY_DELETE_AFTER_UPLOAD, value) }

    fun isSignedIn() = googleAccountEmail != null

    fun signOut() {
        prefs.edit {
            remove(KEY_GOOGLE_ACCOUNT)
            remove(KEY_DRIVE_FOLDER_ID)
        }
    }

    companion object {
        private const val KEY_RECORDING_ENABLED  = "recording_enabled"
        private const val KEY_AUTO_UPLOAD         = "auto_upload"
        private const val KEY_WIFI_ONLY           = "wifi_only"
        private const val KEY_GOOGLE_ACCOUNT      = "google_account"
        private const val KEY_DRIVE_FOLDER_ID     = "drive_folder_id"
        private const val KEY_DRIVE_FOLDER_NAME   = "drive_folder_name"
        private const val KEY_RECORDING_FORMAT    = "recording_format"
        private const val KEY_DELETE_AFTER_UPLOAD = "delete_after_upload"

        const val FORMAT_M4A = "m4a"
        const val FORMAT_MP3 = "mp3"

        @Volatile private var INSTANCE: AppPreferences? = null
        fun getInstance(context: Context) =
            INSTANCE ?: synchronized(this) {
                AppPreferences(context.applicationContext).also { INSTANCE = it }
            }
    }
}
