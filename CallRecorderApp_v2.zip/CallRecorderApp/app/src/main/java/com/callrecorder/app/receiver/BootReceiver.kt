package com.callrecorder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Ensures the app can receive phone state changes after reboot.
 * No explicit service restart needed — the PhoneStateReceiver is always registered
 * via the manifest, so this receiver just logs reboot for debugging purposes.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d("BootReceiver", "Device booted — Call Recorder is ready.")
        }
    }
}
