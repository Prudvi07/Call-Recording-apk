package com.callrecorder.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.callrecorder.app.R
import com.callrecorder.app.databinding.ItemRecordingBinding
import com.callrecorder.app.utils.Recording
import com.callrecorder.app.utils.UploadStatus
import java.text.SimpleDateFormat
import java.util.*

class RecordingsAdapter(
    private val onDelete: (Recording) -> Unit,
    private val onRetry:  (Recording) -> Unit,
    private val onOpen:   (Recording) -> Unit
) : ListAdapter<Recording, RecordingsAdapter.ViewHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<Recording>() {
            override fun areItemsTheSame(a: Recording, b: Recording) = a.id == b.id
            override fun areContentsTheSame(a: Recording, b: Recording) = a == b
        }
        private val DATE_FMT = SimpleDateFormat("MMM dd, yyyy  HH:mm", Locale.getDefault())
    }

    inner class ViewHolder(val b: ItemRecordingBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(rec: Recording) {
            b.tvPhoneNumber.text = rec.phoneNumber.ifBlank { "Unknown" }
            b.tvCallType.text    = rec.callType
            b.tvDate.text        = DATE_FMT.format(Date(rec.timestampMs))
            b.tvDuration.text    = formatDuration(rec.durationSeconds)
            b.tvFileSize.text    = formatSize(rec.fileSizeBytes)

            val (statusText, statusColor) = when (rec.uploadStatus) {
                UploadStatus.UPLOADED  -> "✓ Uploaded"  to R.color.status_uploaded
                UploadStatus.UPLOADING -> "⟳ Uploading" to R.color.status_uploading
                UploadStatus.FAILED    -> "✗ Failed"    to R.color.status_failed
                else                   -> "⏳ Pending"  to R.color.status_pending
            }
            b.tvStatus.text = statusText
            b.tvStatus.setTextColor(ContextCompat.getColor(b.root.context, statusColor))

            b.btnRetry.visibility =
                if (rec.uploadStatus == UploadStatus.FAILED) android.view.View.VISIBLE
                else android.view.View.GONE

            b.root.setOnClickListener  { onOpen(rec) }
            b.btnDelete.setOnClickListener { onDelete(rec) }
            b.btnRetry.setOnClickListener  { onRetry(rec) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemRecordingBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) =
        holder.bind(getItem(position))

    private fun formatDuration(seconds: Long): String {
        val m = seconds / 60
        val s = seconds % 60
        return "%d:%02d".format(m, s)
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
        bytes >= 1_000     -> "%.1f KB".format(bytes / 1_000.0)
        else               -> "$bytes B"
    }
}
