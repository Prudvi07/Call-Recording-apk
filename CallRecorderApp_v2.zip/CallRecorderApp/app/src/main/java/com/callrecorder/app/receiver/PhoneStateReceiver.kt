package com.callrecorder.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import android.util.Log
import com.callrecorder.app.service.CallRecordingService
import com.callrecorder.app.utils.AppPreferences

class PhoneStateReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "PhoneStateReceiver"
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var callStarted = false
        private var savedNumber = ""
        private var isOutgoing = false
    }

    override fun onReceive(context: Context, intent: Intent) {
        val prefs = AppPreferences.getInstance(context)
        if (!prefs.isRecordingEnabled) return

        // Capture outgoing number before call connects
        if (intent.action == Intent.ACTION_NEW_OUTGOING_CALL) {
            savedNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER) ?: ""
            isOutgoing = true
            return
        }

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
        val incomingNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""

        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                lastState = TelephonyManager.CALL_STATE_RINGING
                savedNumber = incomingNumber
                isOutgoing = false
                callStarted = false
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                if (lastState != TelephonyManager.CALL_STATE_OFFHOOK) {
                    // Call just answered/started
                    lastState = TelephonyManager.CALL_STATE_OFFHOOK
                    callStarted = true
                    val callType = if (isOutgoing) "OUTGOING" else "INCOMING"
                    Log.d(TAG, "Call started: $savedNumber ($callType)")
                    CallRecordingService.startRecording(context, savedNumber, callType)
                }
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                if (lastState != TelephonyManager.CALL_STATE_IDLE) {
                    lastState = TelephonyManager.CALL_STATE_IDLE
                    if (callStarted) {
                        Log.d(TAG, "Call ended: $savedNumber")
                        CallRecordingService.stopRecording(context)
                        callStarted = false
                    }
                }
            }
        }
    }
}
