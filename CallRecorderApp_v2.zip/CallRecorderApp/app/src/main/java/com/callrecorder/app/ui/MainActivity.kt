package com.callrecorder.app.ui

import android.Manifest
import android.accounts.AccountManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.services.drive.DriveScopes
import com.callrecorder.app.R
import com.callrecorder.app.databinding.ActivityMainBinding
import com.callrecorder.app.utils.AppPreferences
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var prefs: AppPreferences
    private lateinit var adapter: RecordingsAdapter

    // ── Permission launcher ──────────────────────────────────────────────────

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (!allGranted) showPermissionRationale()
    }

    // ── Google Sign-In launcher ──────────────────────────────────────────────

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        task.addOnSuccessListener { account ->
            prefs.googleAccountEmail = account.email
            updateSignInUi()
            Toast.makeText(this, "Signed in as ${account.email}", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener {
            Toast.makeText(this, "Sign-in failed: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        prefs = AppPreferences.getInstance(this)
        setupRecyclerView()
        setupSwitches()
        setupFab()
        observeRecordings()
        requestRequiredPermissions()
        updateSignInUi()
    }

    private fun setupRecyclerView() {
        adapter = RecordingsAdapter(
            onDelete = { viewModel.deleteRecording(it) },
            onRetry  = { viewModel.retryUpload(it) },
            onOpen   = { startActivity(RecordingDetailActivity.newIntent(this, it.id)) }
        )
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
    }

    private fun setupSwitches() {
        binding.switchRecording.isChecked = prefs.isRecordingEnabled
        binding.switchAutoUpload.isChecked = prefs.isAutoUploadEnabled

        binding.switchRecording.setOnCheckedChangeListener { _, checked ->
            viewModel.toggleRecording(checked)
        }
        binding.switchAutoUpload.setOnCheckedChangeListener { _, checked ->
            viewModel.toggleAutoUpload(checked)
            if (checked && !prefs.isSignedIn()) startGoogleSignIn()
        }
    }

    private fun setupFab() {
        binding.fabUploadAll.setOnClickListener {
            if (!prefs.isSignedIn()) {
                startGoogleSignIn()
            } else {
                viewModel.uploadAll()
                Toast.makeText(this, "Uploading pending recordings…", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeRecordings() {
        lifecycleScope.launch {
            viewModel.recordings.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility =
                    if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    // ── Google Sign-In ───────────────────────────────────────────────────────

    private fun startGoogleSignIn() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        val client = GoogleSignIn.getClient(this, gso)
        signInLauncher.launch(client.signInIntent)
    }

    private fun signOut() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
        GoogleSignIn.getClient(this, gso).signOut().addOnCompleteListener {
            prefs.signOut()
            updateSignInUi()
            Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateSignInUi() {
        val email = prefs.googleAccountEmail
        binding.tvAccount.text = if (email != null) "Signed in: $email" else "Not signed in"
        binding.btnSignIn.text  = if (email != null) "Sign Out" else "Sign In with Google"
        binding.btnSignIn.setOnClickListener {
            if (prefs.isSignedIn()) signOut() else startGoogleSignIn()
        }
    }

    // ── Permissions ──────────────────────────────────────────────────────────

    private fun requestRequiredPermissions() {
        val required = mutableListOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            required += Manifest.permission.POST_NOTIFICATIONS
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            required += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        val missing = required.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    private fun showPermissionRationale() {
        AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage(
                "Call Recorder needs phone state, call log, and microphone permissions to record calls. " +
                "Please grant them in Settings."
            )
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", packageName, null)
                })
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Options Menu ─────────────────────────────────────────────────────────

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
