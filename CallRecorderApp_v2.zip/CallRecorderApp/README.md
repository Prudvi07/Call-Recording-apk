# 📞 Call Recorder App for Android

A fully-featured Android app that automatically records phone calls and uploads them to Google Drive.

---

## ✨ Features

- **Automatic call recording** — detects incoming and outgoing calls and records them automatically
- **Google Drive upload** — uploads recordings to a dedicated Drive folder after each call
- **Built-in playback** — listen to recordings directly in the app
- **Upload queue** — failed uploads retry automatically with exponential backoff
- **Configurable settings** — Wi-Fi-only uploads, folder name, recording format (M4A/MP3), auto-delete after upload
- **Room database** — all recordings tracked with phone number, duration, file size, and upload status

---

## 🗂️ Project Structure

```
CallRecorderApp/
├── app/src/main/java/com/callrecorder/app/
│   ├── ui/
│   │   ├── MainActivity.kt           # Main screen with recording list
│   │   ├── MainViewModel.kt          # ViewModel for recordings list
│   │   ├── RecordingsAdapter.kt      # RecyclerView adapter
│   │   ├── RecordingDetailActivity.kt# Detail view + audio playback
│   │   └── SettingsActivity.kt       # App settings
│   ├── service/
│   │   └── CallRecordingService.kt   # Foreground service for recording
│   ├── receiver/
│   │   ├── PhoneStateReceiver.kt     # Detects call start/end
│   │   └── BootReceiver.kt           # Re-enables after reboot
│   ├── drive/
│   │   ├── DriveHelper.kt            # Google Drive API wrapper
│   │   └── DriveUploadWorker.kt      # WorkManager upload task
│   └── utils/
│       ├── Database.kt               # Room DB, DAO, Recording entity
│       └── AppPreferences.kt         # SharedPreferences wrapper
└── app/src/main/res/
    ├── layout/                       # All XML layouts
    ├── drawable/                     # Vector icons
    ├── values/                       # Colors, strings, themes
    └── menu/                         # Toolbar menu
```

---

## 🚀 Setup Instructions

### 1. Prerequisites

- Android Studio Hedgehog or newer
- Android SDK 26+ (Android 8.0+)
- A Google account with Google Drive

### 2. Google Drive API Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project (or use an existing one)
3. Enable the **Google Drive API**
4. Go to **APIs & Services → Credentials**
5. Create an **OAuth 2.0 Client ID** → select **Android**
6. Enter your app's package name: `com.callrecorder.app`
7. Get your app's SHA-1 fingerprint:
   ```bash
   keytool -keystore ~/.android/debug.keystore -list -v -alias androiddebugkey -storepass android
   ```
8. Enter the SHA-1 into the Cloud Console
9. Download `google-services.json` and place it in `/app/`

### 3. Build & Run

```bash
# Clone / open project in Android Studio
# Sync Gradle
# Run on a physical device (emulators can't receive real calls)
```

> ⚠️ **Physical device required** — call recording needs real telephony hardware.

### 4. Grant Permissions

On first launch, grant all requested permissions:
- `READ_PHONE_STATE` + `READ_CALL_LOG` — detect calls
- `RECORD_AUDIO` — capture audio
- `POST_NOTIFICATIONS` — show recording notification

### 5. Sign In to Google

Tap **Sign In with Google** on the main screen and authorize Drive access.

---

## ⚙️ Settings

| Setting | Description |
|---|---|
| Enable Recording | Toggle automatic recording on/off |
| Auto Upload | Upload each recording to Drive automatically |
| Upload on Wi-Fi only | Save mobile data |
| Drive Folder Name | Name of folder created in your Drive root |
| Recording Format | M4A (smaller) or MP3 (wider compatibility) |
| Delete after upload | Remove local file once safely uploaded |

---

## 📱 Android Version Notes

| Android | Recording Quality |
|---|---|
| 8–9 | Full call audio (both sides) via `VOICE_CALL` |
| 10–12 | Microphone side only (OS restriction) |
| 13–14 | Microphone side only; notifications permission required |

> For best results on Android 10+, consider setting your app as the **default Phone app** which grants full `VOICE_CALL` audio source access.

---

## ⚖️ Legal Notice

Call recording laws vary by jurisdiction. Many countries and states require **all-party consent** before recording. Ensure you comply with the laws in your region. This app is intended for personal, lawful use only.

---

## 🔧 Customization Tips

- Change `driveFolderName` in Settings to organise recordings by month
- Enable `deleteAfterUpload` if storage space is limited
- Use the retry button on failed uploads or tap "Upload All" FAB
- The app automatically retries failed uploads when connectivity returns
